const BRAND = 'TINSHISOURCE.XYZ';

function brandEmbed(embed) {
  if (!embed || typeof embed.setFooter !== 'function') {
    return embed;
  }

  const current = embed.data?.footer || {};
  const existing = current.text || '';

  if (existing.includes(BRAND)) return embed;

  const text = existing
    ? `${existing} • ${BRAND}`
    : BRAND;

  embed.setFooter({
    ...current,
    text
  });

  return embed;
}

module.exports = { brandEmbed, BRAND };
