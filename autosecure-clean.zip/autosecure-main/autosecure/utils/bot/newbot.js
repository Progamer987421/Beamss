const modalBuilder = require("../modalBuilder");
const { TextInputStyle } = require("discord.js");

module.exports = async function handlenewbot(interaction, userid, number) {
    interaction.showModal(modalBuilder(
        `handlenewbot|${userid}|${number}`,
        `🤖 Create Your Bot`,
        [
            {
                setCustomId: 'token',
                setMaxLength: 256,
                setMinLength: 0,
                setRequired: true,
                setLabel: "Bot Token from Discord Developer Portal",
                setPlaceholder: "Paste your bot token here...",
                setStyle: TextInputStyle.Short
            }
        ]
    ));
};
