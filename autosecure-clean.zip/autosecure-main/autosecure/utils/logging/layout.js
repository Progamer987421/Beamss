module.exports = {
    format: "compact",
    timestamp: true,
    _k: ""
};
